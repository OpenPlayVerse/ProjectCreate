#!/bin/bash
java -jar update-pack.jar "java" "client" "https://github.com/OpenPlayVerse/ProjectCreate" "main"
